import json,subprocess,copy,xml.etree.ElementTree as E
from pathlib import Path
root=Path('/workspace/hunter-art-build/zzzz_revolver_samson')
groups=json.loads(Path('/workspace/hunter-art-build/designs.json').read_text())
groups.append([[300,'Aries: ivory ram horns'],[342,'Blue Cap: emerald skull mushroom cap']])
atlas=json.loads(Path('/workspace/hunter-art-build/atlases.json').read_text())
out=root/'resources/gfx/characters/hunter_art173';out.mkdir(parents=True,exist_ok=True)
native=E.parse(root/'resources/gfx/001.000_player_hunter_b_v153.anm2').getroot()
costumes=E.parse(root/'content/costumes2.xml')
for node in list(costumes.getroot()):
    if node.get('anm2path','').startswith('hunter_art173/'):costumes.getroot().remove(node)
face={1,2,3,4,6,13,14,31,34,49,55,62,68,69,75,76,89,93,103,110,126,132,138,143}
body={29,39,46,50,63,70,82,92,117,119,123,129,130,134}
labels='泪痕|第三只眼|灵能符文|兽纹|金色眼纹|荆棘血冠|感染纹|充血眼纹|骨钥匙|燃烧引线|木勺发饰|蕾丝领|唇印|铁丝冠|血色符印|猎手胸甲|兔骨胸针|金箭|红色发射器|暗影护符|五芒星冠|礼帽护目镜|磁铁饰物|后眼|獠牙|电池背包|缝制价签|机械单眼|巧克力痕|皮甲肩饰|银框眼镜|骨框眼镜|独角|恶魔印记|恶魔角|蝠翼|铁钉|四角|蜘蛛咬痕|碎石|矿灯帽|绷带|金色光学面罩|光环|鼻涕|寄生虫|炸弹护甲|金币冠|红色瞳片|灵魂薄纱|电极|乌鸦|骨角红宝石|血瓶|血宝石鹿角|幽灵使魔|割痕|厚衬领|马骨护符|煤灰|猫尾|血泪|银冠|青色眼纹|羊角|翡翠骨饰蘑菇帽'.split('|')
manifest=[];rows=[];index=0
for groupIndex,group in enumerate(groups):
    src=Path(atlas[groupIndex]);dims=subprocess.check_output(['magick','identify','-format','%w %h',str(src)],text=True).split();w,h=map(int,dims)
    cols,rs=(6,8)if groupIndex<4 else(3,2)
    for j,(id,label)in enumerate(group):
        for direction in range(3):
            slot=j*3+direction;x0=round(slot%cols*w/cols);x1=round((slot%cols+1)*w/cols);y0=round(slot//cols*h/rs);y1=round((slot//cols+1)*h/rs)
            dest=out/f'{id}_{direction}.png'
            subprocess.run(['magick',str(src),'-crop',f'{x1-x0}x{y1-y0}+{x0}+{y0}','+repage','-trim','+repage','-resize','220x220','-gravity','center','-background','none','-extent','256x256',str(dest)],check=True)
        subprocess.run(['magick',*[str(out/f'{id}_{d}.png')for d in range(3)],'+append',str(out/f'{id}.png')],check=True)
        r=E.Element('AnimatedActor');E.SubElement(r,'Info',CreatedBy='Hunter art pack',Version='1',Fps='30')
        c=E.SubElement(r,'Content');ss=E.SubElement(c,'Spritesheets')
        E.SubElement(ss,'Spritesheet',Id='0',Path=f'{id}.png')
        ls=E.SubElement(c,'Layers')
        layerName='body0'if id in body else'head4'
        E.SubElement(ls,'Layer',Id='0',Name=layerName,SpritesheetId='0')
        E.SubElement(c,'Nulls');E.SubElement(c,'Events');an=E.SubElement(r,'Animations',DefaultAnimation='WalkDown'if id in body else'HeadDown')
        for original in native.findall('Animations/Animation'):
            a=E.SubElement(an,'Animation',**original.attrib)
            ra=original.find('RootAnimation');a.append(copy.deepcopy(ra))
            layers=E.SubElement(a,'LayerAnimations');name=a.get('Name')
            direction=2 if 'Up'in name else 1 if 'Left'in name or 'Right'in name else 0
            source=original.find("LayerAnimations/LayerAnimation[@LayerId='%s']"%('1'if id in body else'4'))
            for d in [direction]:
                la=E.SubElement(layers,'LayerAnimation',LayerId='0',Visible='true')
                if d!=direction or source is None:continue
                if id in face and direction==2 and id!=55:continue
                for frame in source.findall('Frame'):
                    f=copy.deepcopy(frame);la.append(f)
                    factor=.48 if id in face else .72 if id in body else .9
                    # Convert 128px native head/body coordinates to 256px art.
                    sx=float(f.get('XScale','33'));sy=float(f.get('YScale','33'))
                    targetY=(50 if id in {2,3,34} else 100 if id in {31,49,62,69} else 90) if id in face else 68 if id in body else 40
                    delta=(targetY-float(f.get('YPivot','112')))*sy/100
                    f.set('YPosition',str(float(f.get('YPosition','0'))+delta))
                    f.set('XPosition',str(float(f.get('XPosition','0'))))
                    for k,v in dict(XCrop=str(direction*256),YCrop='0',Width='256',Height='256',XPivot='128',YPivot='128',XScale=str(abs(sx)*factor/2*(-1 if 'Left'in name else 1)),YScale=str(sy*factor/2)).items():f.set(k,v)
            E.SubElement(a,'NullAnimations');E.SubElement(a,'Triggers')
        path=f'hunter_art173/{id}.anm2'
        E.ElementTree(r).write(root/'resources/gfx/characters'/path,encoding='utf-8',xml_declaration=True)
        E.SubElement(costumes.getroot(),'costume',anm2path=path,type='none',priority='105',hasOverlay='true')
        zh=labels[index];index+=1
        manifest.append('{id=%d,path=%s,label=%s,zh=%s}'%(id,json.dumps('gfx/characters/'+path),json.dumps(label),json.dumps(zh,ensure_ascii=False)))
        rows.append(f'| {id} | {label.split(":")[0]} | {zh} | '+('效果触发'if id in {34,39,49,77,83,93,123,126,130,122}else'持有时')+' |')
costumes.write(root/'content/costumes2.xml',encoding='utf-8',xml_declaration=True)
(root/'hunter_costume_manifest.lua').write_text('return {\n'+',\n'.join(manifest)+'\n}\n')
p=root/'main.lua';s=p.read_text();s=s.replace('\ninclude("tainted_hunter_costumes")(mod, TAINTED_PLAYER_TYPE)\n','');s+='\ninclude("tainted_hunter_costumes")(mod, TAINTED_PLAYER_TYPE)\n';p.write_text(s)
(root/'COSTUME_CATALOG.md').write_text('# 里猎手外观包 1.73-art\n\n66项道具；每项提供正面、侧面、背面素材，左向镜像侧面。面部特效背面隐藏。美术是重新设计的配饰，并非直接复制魔理沙整个人物。\n\n| ID | 道具 | 设计 | 触发 |\n|---|---|---|---|\n'+'\n'.join(rows)+'\n\n纯外观，不改变战斗、数值或道具所有权。EID追加中英文外观说明，Stats+数值模块保留。未经过游戏实测；需要验证服装组合、特殊形态、主动持续时间和继续游戏后的恢复。\n')
meta=E.parse(root/'metadata.xml');meta.getroot().find('version').text='1.73-art';meta.getroot().find('description').text='Tainted Hunter: 66 custom high-resolution directional cosmetic overlays. Gameplay remains v1.72. In-game visual validation pending.';meta.write(root/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Generated',index,'costumes')

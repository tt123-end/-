local root='/workspace/hunter-art-build/zzzz_revolver_samson/'
function include(n)return assert(loadfile(root..n..'.lua'))()end
local callbacks={}
local mod={AddCallback=function(_,event,fn)callbacks[event]=callbacks[event]or{};table.insert(callbacks[event],fn)end}
ModCallbacks={MC_POST_PEFFECT_UPDATE='tick',MC_USE_ITEM='use',MC_POST_NEW_ROOM='room',MC_POST_UPDATE='post'}
NullItemID={ID_LOST_CURSE=112}
local frame=0;local players={}
function Game()return{GetFrameCount=function()return frame end,GetNumPlayers=function()return #players end}end
local costumeId=0
Isaac={GetCostumeIdByPath=function()costumeId=costumeId+1;return costumeId end,
GetItemIdByName=function()return 999 end,GetItemConfig=function()return{GetCollectible=function(_,id)return{id=id}end}end,
GetPlayer=function(i)return players[i+1]end}
local function player()
 local p={kind=42,data={},items={},effects={},outfits={},removed={},lost=false}
 function p:GetData()return self.data end
 function p:GetPlayerType()return self.kind end
 function p:IsCoopGhost()return false end
 function p:GetCollectibleNum(id)return self.items[id]or 0 end
 function p:GetEffects()return{GetCollectibleEffectNum=function(_,id)return p.effects[id]or 0 end,HasCollectibleEffect=function(_,id)return(p.effects[id]or 0)>0 end,HasNullEffect=function()return p.lost end}end
 function p:RemoveCostume(c)self.removed[c.id]=true end
 function p:AddCostume(c)self.removed[c.id]=nil end
 function p:AddNullCostume(id)assert(not self.outfits[id],'duplicate costume');self.outfits[id]=true end
 function p:TryRemoveNullCostume(id)self.outfits[id]=nil end
 return p
end
local function fire(e,...)for _,f in ipairs(callbacks[e]or{})do f(nil,...)end end
include('tainted_hunter_costumes')(mod,42)
local defs=include('hunter_costume_manifest');assert(#defs==66)
local p=player();local q=player();players={p,q}
p.items[1]=1;q.items[1]=1;fire('tick',p);fire('tick',q)
assert(p.outfits[1]and q.outfits[1]);fire('tick',p)
p.items[1]=nil;fire('tick',p);assert(not p.outfits[1]and q.outfits[1])
p.items[34]=1;fire('tick',p);assert(not p.data.hunterArt173.applied[34])
fire('use',34,nil,p);fire('tick',p);assert(p.data.hunterArt173.applied[34])
fire('room');assert(not p.data.hunterArt173.applied[34])
p.items[999]=1;fire('tick',p);assert(p.data.hunterArt173.applied[69]);assert(p.items[999]==1)
p.lost=true;fire('tick',p);assert(next(p.outfits)==nil)
p.lost=false;fire('tick',p);assert(p.data.hunterArt173.applied[69])
p.kind=0;fire('tick',p);assert(next(p.outfits)==nil)
p.kind=42;p.items[77]=1;fire('use',77,nil,p);fire('tick',p);assert(p.data.hunterArt173.applied[77]);frame=181;fire('tick',p);assert(not p.data.hunterArt173.applied[77])
local registered
EID={player=p,getLanguage=function()return'zh_cn'end,addDescriptionModifier=function(_,_,condition,fn)registered={condition,fn}end}
fire('post');local desc={ObjType=5,ObjVariant=100,ObjSubType=69,Description='original mechanics'}
assert(registered[1](desc));assert(registered[2](desc).Description:find('original mechanics',1,true)==1)
print('PASS: 66 definitions, two-player isolation, no duplicate additions, removal, active timing, room reset, replacement item, Lost restoration, character change, EID append')
